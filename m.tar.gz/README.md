cfg cache
